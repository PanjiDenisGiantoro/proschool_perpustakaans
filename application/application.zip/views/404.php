<div class="content-wrapper">

	<section class="content">
      <!-- Main row -->
      <div class="row">
			<div class="col-xs-12">
          <div class="box">
				
            <!-- /.box-header -->
            <div class="box-body">
                    <div class="well">
                        <h1>Maaf Halaman Tidak Ditemukan</h1>
                    </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
      <!-- /.row -->
    </section>
</div>